# Empty Mod (Fabric, Minecraft 1.16.5)

A Fabric mod that does nothing. It loads, prints one line to the log
confirming it started, and otherwise has zero effect on gameplay —
no items, blocks, entities, mixins, or event listeners.

It's meant as a clean, guaranteed-working skeleton you can either use
as a placeholder or build on later.

## Requirements

- Java 8 JDK (Minecraft 1.16.5 / Fabric Loom 0.6 target Java 8)
- An internet connection the first time you build (Gradle needs to
  download Loom, Minecraft, Yarn mappings, and Fabric API)

## Building

1. Open a terminal in this project's root folder (where `build.gradle` lives).
2. Generate the Gradle wrapper if it's not already present:
   ```
   gradle wrapper
   ```
   (Requires a system-installed Gradle just for this one-time step —
   or download the wrapper files from the official Fabric example mod
   repo: https://github.com/FabricMC/fabric-example-mod)
3. Build the mod:
   - Linux/macOS: `./gradlew build`
   - Windows: `gradlew.bat build`
4. The compiled jar appears at `build/libs/emptymod-1.0.0.jar`.

## Installing

1. Install Fabric Loader for Minecraft 1.16.5 (via the Fabric installer:
   https://fabricmc.net/use/).
2. Install Fabric API 0.34.9+1.16 (or newer 1.16.5-compatible build)
   into your `mods` folder — this mod depends on it.
3. Drop `emptymod-1.0.0.jar` into your `.minecraft/mods` folder.
4. Launch the game with the Fabric profile. Check the log for:
   `EmptyMod loaded. It does nothing, as designed.`

## Project layout

```
emptymod/
├── build.gradle
├── gradle.properties
├── settings.gradle
├── README.md
└── src/main/
    ├── java/com/example/emptymod/EmptyMod.java
    └── resources/fabric.mod.json
```

## Extending it later

If you ever want it to actually do something, `EmptyMod.onInitialize()`
in `EmptyMod.java` is the entry point — that's where you'd register
items, blocks, or event callbacks.

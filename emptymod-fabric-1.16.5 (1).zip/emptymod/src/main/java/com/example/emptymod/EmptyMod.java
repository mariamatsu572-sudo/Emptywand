package com.example.emptymod;

import net.fabricmc.api.ModInitializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This mod intentionally does nothing.
 * It registers no items, blocks, entities, or events.
 * It only logs a line on startup so you can confirm it loaded.
 */
public class EmptyMod implements ModInitializer {
	public static final String MOD_ID = "emptymod";
	public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("EmptyMod loaded. It does nothing, as designed.");
	}
}
